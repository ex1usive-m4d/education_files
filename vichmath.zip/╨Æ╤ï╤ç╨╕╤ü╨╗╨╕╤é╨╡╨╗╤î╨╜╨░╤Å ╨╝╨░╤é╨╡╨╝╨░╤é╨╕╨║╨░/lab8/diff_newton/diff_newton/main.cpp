//
//  main.cpp
//  diff_newton
//
//  Created by Иван on 07.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;
void iNewton(double OX[],double OY[]){
    double result = OY[0], F, znam, _x;
    
    cin  >> _x;
    
    for(int i=1; i<5; i++){
        F=0;
        for(int j=0; j<=i; j++){
            znam=1;
            for(int k=0; k<=i; k++){
                if (k!=j)
                    znam*=(OX[j]-OX[k]);
            }
            F+=OY[j]/znam;
        }
        for(int k=0; k<i; k++)
            F=F*(_x-OX[k]);
        result+=F;
    }
    
    cout << result;
    
}
int i,j,k;
int df(double x){return 2*x;}
int main(){
   
    double t = (2.0/5);
    double OX[5];double OY[5];
    for (i=0; i<5; i++){
        OX[i] = i;
        OY[i] = df(OX[i]);
    }
    iNewton(OX,OY);
    return 0;
}