//
//  main.cpp
//  diff_lagrange
//
//  Created by Иван on 03.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
//8 lab lagrange
#include <iostream>
#include <iomanip>

using namespace std;

double f(double x){//функция
    return 5+x*x;
}


double dL(double x, int n, double x_arr[], double y_arr[]){//diff lagrange
    
    double sum1 = 0;
    for (int i = 0; i < n; ++i){
        
        double sum2 = 0;
        for (int j = 0; j < n; ++j)
        {
            if (j != i)
            {
                double p = 1;
                for (int k = 0; k < n; ++k)
                    if (k != i && k != j)
                        p *= (x - x_arr[k]) / (x_arr[i] - x_arr[k]);
                sum2 += p/(x_arr[i] - x_arr[j]);
            }
        }
        sum1 += y_arr[i]*sum2;
    }
    
    return sum1;
}

int main()
{
    
    const int N = 5;
    double number=0;
    double x_arr[N], y_arr[N];
    for (int i = 0; i < N; i++)
    {
        x_arr[i] = i;
        y_arr[i] = f(x_arr[i]);
        cout<<"x:"<<x_arr[i]<<" y:"<<y_arr[i]<<endl;
    }
    cin>>number;
    cout << setw(3) << "x";
    cout << setw(10) << "dL(x)" << endl;
    cout<<setw(3)<<number;
    cout<<setw(10)<<dL(number, N, x_arr, y_arr)<<endl;
   
}