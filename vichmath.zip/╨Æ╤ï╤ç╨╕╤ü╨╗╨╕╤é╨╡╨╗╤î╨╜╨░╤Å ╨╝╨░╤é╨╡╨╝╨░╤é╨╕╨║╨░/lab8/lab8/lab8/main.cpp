#include <iostream>

using namespace std;

class interpol{   //  Î‡ÒÒ ÙÛÌÍˆËÈ ‰Îˇ ËÌÚÂÔÓÎËÓ‚‡ÌËˇ
public:
    double Lagrange();   //Œ·˙ˇ‚ÎˇÂÏ À‡„‡ÌÊ‡
    double Newton();   //Œ·˙ˇ‚ÎˇÂÏ Õ¸˛ÚÓÌ‡
    int i,j,k;
    
    interpol(){
        cout << ("VVedite kol-vo otrezkov: "); //¬‚Ó‰ËÏ ÍÓÎË˜ÂÒÚ‚Ó ÓÚÂÁÍÓ‚ ÏÂÊ‰Û ÚÓ˜Í‡ÏË(ÛÁÎ‡ÏË)
        cin  >> variants;
        double t = (2.0/variants); // ◊ËÒÎÓ 2.0 ÔÓÎÛ˜‡ÂÏ ËÁ ‰ÎËÌ˚ ÓÚÂÁÍ‡ Ì‡ ÍÓÚÓÓÏ ‡ÒÒÏ‡ÚË‚‡ÂÚÒˇ ÙÛÌÍˆËˇ. Õ‡ÔËÏÂ ‚ ÏÓ∏Ï ÒÎÛ˜‡Â ÓÚÂÁÓÍ ÓÚ -1 ‰Ó 1, Ú.Â. 2
        OX = new double[variants];
        OY = new double[variants];
        for (i=0; i<variants; i++){
            OX[i] = -1+t*i;
            OY[i] = 1/(1+OX[i]*OX[i]);
        }
        
        cout << "x,y:" << endl;
        for(i=0; i<variants; i++){
            cout <<("tochka [") << i+1 << "]=" << OX[i] << " , " << OY[i] << endl;
        }
    }
    
private:
    double *OX,*OY;
    int variants,n;
};

int main(int argc, char *argv[]){
    double x, arg, result=0.0;
    
    interpol func;
    cout << func.Lagrange() << endl;
    cout << func.Newton()   << endl;
    
    
    return EXIT_SUCCESS;
}

double interpol::Lagrange(){ // —Ó·ÒÚ‚ÂÌÌÓ ÔÓÎËÌÓÏ À‡„‡ÌÊ‡
    double result = 0.0, _x;
    
    cout <<("VVedite argum dlya polinoma lagranga: ");
    cin  >> _x;
    
    for(int i=0; i<variants; i++){
        double P = 1.0;
        for(int j=0; j<variants; j++)
            if(j-i)
                P*=(_x-OX[j])/(OX[i]-OX[j]);
        result+=P*OY[i];
    }
    
    cout << ("Otvet: ");
    return result;
}

double interpol::Newton(){ //¿ ˝ÚÓ ÒÓÍ‡˘∏ÌÌ‡ˇ ÙÓÏÛÎ‡ Õ¸˛ÚÓÌ‡
    double result = OY[0], F, znam, _x;
    
    cout << ("Vvedite argument dlya metoda Newtona:");
    cin  >> _x;
    
    for(i=1; i<variants; i++){
        F=0;
        for(j=0; j<=i; j++){
            znam=1;
            for(k=0; k<=i; k++){
                if (k!=j)
                    znam*=(OX[j]-OX[k]);
            }
            F+=OY[j]/znam;
        }
        for(k=0; k<i; k++)
            F=F*(_x-OX[k]);
        result+=F;
    }
    
    cout << ("Otvet: ");
    return result;
}
