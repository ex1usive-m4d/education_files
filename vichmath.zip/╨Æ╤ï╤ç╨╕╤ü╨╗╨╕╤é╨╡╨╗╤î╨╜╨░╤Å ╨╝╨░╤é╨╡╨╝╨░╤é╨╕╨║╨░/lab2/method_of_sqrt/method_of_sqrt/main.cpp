//
//  main.cpp
//  method_of_sqrt
//
//  Created by Иван on 19.09.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <math.h>
#include <ccomplex>
#include <stdlib.h>
using namespace std;

int main()
{
    complex <double> a[100][100], t[100][100],b[100],x[100],y[100], sum;
    
    int n,m,i, j, k;
   
    cin >> n;m=n;
    cout << " Заполните матрицу(без свободных элементов) "<<endl;
    for (i = 0; i<n; i++)
        for (j = 0; j<m; j++)
        {
            cin >> a[i][j];
            
        }
    cout << " Введите свободные элементы: " << endl;
    for (i = 0; i < n; i++) cin >> b[i];
    
    
    for (i = 0; i<n; i++)
        for (j = 0; j<m; j++)
        {
            if (j > 0){
                t[0][0] = sqrt(a[0][0]); t[0][j] = (a[0][j] / t[0][0]);
            }
            if ((i>0) && (i <= (n - 1))) {
				            sum = 0;
                for (k = 0; k < i ; k++)
                {
                    sum = sum +t[k][i]*t[k][i];
                };
                t[i][i] = sqrt(a[i][i] - sum);
            }
            
            if (i < j) {
                for (sum=0,k = 0; k < (i); k++)
                {
                    sum = sum + t[k][i] * t[k][j];
                };
                t[i][j] = (a[i][j] - sum) / t[i][i];
            }
            if (i > j) 	t[i][j] = 0;
            
        };
    cout << " Транспонированная матрица Т:" << endl;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            cout << " " << t[i][j];
        }
        cout << endl;
    };
    y[0] = b[0] / t[0][0];
    for (i = 1; i < n; i++)
    {
        for (sum = 0, k = 0; k < i ; k++)
        {
            sum = sum + t[k][i] * y[k];
        };
        y[i] = (b[i] - sum) / t[i][i];
    }
     // x[n] = y[n] / t[n][n];
    for (i = n-1; i >=0; i--)
    {        for (sum=0,k = i+1; k<=n ; k++)
        {
            sum = sum + t[i][k] * x[k];
        };
        x[i] = (y[i] - sum) / t[i][i];
    };
    cout<<endl;
    for (i = 0; i < n; i++)
    {
        cout << "  x[" << i + 1 << "]=" << x[i];
    }
    cout << endl;
    for (i = 0; i < n; i++)
    {
        cout << "  y[" << i + 1 << "]=" << y[i];
    }
    cout << endl;
    
    
    return 0;
}
