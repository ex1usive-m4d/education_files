//
//  main.cpp
//  cir_holetts
//
//  Created by Иван on 02.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h>
using namespace std;

int main()
{   ifstream in ("matrix.txt");
    int i,j,k=0, p=0;
    double a[3][4], x[3],y[3], b[3][3],c[3][3],sum;
    for(i=0; i<3; i++)
    {
        for(j=0; j<4; j++)
        {
            in >> a[i][j];
            if (j==3) {cout<<a[i][j]<<" \n";}
            else cout<<a[i][j]<<" ";
        }
    }
    double temp;
    for(i=0;i<3;i++){
    for(j=0; j<3; j++)
    {   b[i][0]=a[i][0];
        c[0][j]=a[0][j]/b[0][0];
        sum=0;
        for(k=0; k<j; k++)
        {
            sum+=b[i][k]*c[k][j];
        }
        if(j>0 && i>=j){b[i][j]=a[i][j]-sum;}//находим ненулевые элементы матрицы b
        if(i>0 && i<=j){c[i][j]=(a[i][j]-sum)/b[i][i];}//матрицы с
        }
    }//вывод на экран матриц b и с
    for(i=0; i<3; i++)
    {cout<<endl;
        for(j=0; j<3; j++)
        {
            cout<<b[i][j]<<" ";
        }}
    cout<<"\n";
    for(i=0; i<3; i++)
    {cout<<endl;
        for(j=0; j<3; j++)
        {
            cout<<c[i][j]<<" ";
        }
    }
    cout<<"\n\n";
    y[0]=a[0][3]/b[0][0];
    cout<<"\ny[1]="<<y[0]<<" ";
    for(i=1;i<3;i++)
    {
         sum=0;
    for(k=0; k<i; k++)
    {
        sum+=b[i][k]*y[k];
    }
    if(i>0){y[i]=(a[i][3]-sum)/b[i][i];}//находим y
    
        cout<<"y["<<i+1<<"]="<<y[i]<<" "; }
    x[2]=y[2];
    cout<<"\n\n";
    for(i=2;i>=0;i--)
    {
        sum=0;
        for(k=i+1; k<3; k++)
        {
            sum+=c[i][k]*x[k];
        }
        if(i<3){x[i]=y[i]-sum;}//находим x
        cout<<"x["<<i+1<<"]="<<x[i]<<" "; }

            return 0;
}