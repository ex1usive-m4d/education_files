//
//  main.cpp
//  method_of_gaus
//
//  Created by Иван on 14.09.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include<iostream>
#include <math.h>
#include <stdlib.h>
#include <fstream>
using namespace std;

int main()
{
   
    int i,j, n,m, k;
    double a[100][100], tmp,tmp1;

    cin>>n;
   int xm[n];
    cin>>m;
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
            cin>>a[i][j];
    for(i=0;i<n;i++){if(a[i][i]==0){cout<<"матрица вырожденная,вычисление невозможно,выход...."<<endl;exit(100);}}
        cout<<endl;
    if(a[0][m-1]>a[n-1][m-1]){
        for(j=0;j<m;j++)
        {tmp1=a[0][j];
    a[0][j]=a[n-1][j];
    a[n-1][j]=tmp1;
        }}
    cout<<endl;
    //прямой ход
    for (i=0; i<n; i++)
    {
        tmp=a[i][i];
        for (j=n;j>=i;j--)
            a[i][j]/=tmp;
        for (j=i+1;j<n;j++)
        {
            tmp=a[j][i];
            for (k=n;k>=i;k--)
                a[j][k]-=tmp*a[i][k];
        }
    }
    
    for(i=0; i<n; i++)
        for(j=0; j<m; j++)
        {
            if(j==n) cout<<a[i][j]<<endl;
            else cout<<a[i][j]<<" ";
        }
    cout<<endl;
    xm[n-1] = a[n-1][n];
    for (i=n-2; i>=0; i--)
    {
        xm[i] = a[i][n];
        for (j=i+1;j<n;j++) xm[i]-=a[i][j]*xm[j];
    }
    
    for (i=0; i<n; i++)
        cout << xm[i] << " ";
    cout << endl;
    return 0;
}
/*
1 2 3 6
1 2 2 5
1 1 1 3
*/

