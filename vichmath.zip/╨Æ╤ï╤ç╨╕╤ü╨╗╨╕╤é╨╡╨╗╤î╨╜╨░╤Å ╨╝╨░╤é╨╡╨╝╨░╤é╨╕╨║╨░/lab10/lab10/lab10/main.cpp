//
//  main.cpp
//  lab10
//
//  Created by Иван on 04.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include <math.h>
#include <locale>
#include <iostream>

using namespace std;
double xn = 2.7, h = 0.1, x, y, x0 = 1.7;
const int n = 11;
 double k0, k1, k2, k3;
double f(double x, double y)
{
    return cos(y/3.14)+x;
}
void Eiler(double y[])
{cout << "\nMetod Eilera:" << endl;
    for (int i = 0; i<n; ++i)
    {
        
        y[i + 1] = y[i] + h*f(x0 + i*h, y[i]);
    }
    for (int i = 0; i<n; ++i)
    {
        cout << "Znachenie y: " << y[i] << endl;
    }
    
    cout << "\nMetod Eilera s peresch:" << endl;
    for (int i = 0; i<n; ++i)
    {
        y[i + 1] = y[i] + h / 2 * (f(x0 + i*h, y[i]) + f(x0 + (i + 1)*h, y[i] + h*f(x0 + i*h, y[i])));
    }
    for (int i = 0; i<n; ++i)
    {
        cout << "Znachenie y: " << y[i] << endl;
    }}
void Runge(double y[]){
    cout << "\nMetod Runge-Kutta:" << endl;
    for (int i = 0; i<n; ++i)
    {
        k0 = h*f(x0 + i*h, y[i]);
        k1 = h*f(x0 + i*h + h / 2, y[i] + k0 / 2);
        k2 = h*f(x0 + i*h + h / 2, y[i] + k1 / 2);
        k3 = h*f(x0 + i*h + h, y[i] + k2);
        y[i + 1] = y[i] + (k0 + 2 * k1 + 2 * k2 + k3) / 6;
    }
    for (int i = 0; i<n; ++i)
    {
        cout << "Znachenie y : " << y[i] << endl;
    }}
void addams(double y[]){
    cout<<"\nmethod Addams\n";
    for (int i = 0; i<4; ++i)
{
    k0 = h*f(x0 + i*h, y[i]);
    k1 = h*f(x0 + i*h + h / 2, y[i] + k0 / 2);
    k2 = h*f(x0 + i*h + h / 2, y[i] + k1 / 2);
    k3 = h*f(x0 + i*h + h, y[i] + k2);
    y[i + 1] = y[i] + (k0 + 2 * k1 + 2 * k2 + k3) / 6;
}
    for (int i = 4; i<n; i++)
        y[i] = y[i - 1] + h / 24 * (55 * f(x0 + (i - 1)*h, y[i - 1])-59 * f(x0 + (i - 2)*h, y[i - 2])+37 * f(x0 + (i - 3)*h, y[i - 3])-9 * f(x0 + (i - 4)*h, y[i - 4]));
    for (int i = 0; i<n; ++i)
    {
        
        cout << "Znach y: " << y[i] << endl;
    }}
int main()
{
    double y[100];
    y[0] = 5.3;
    Eiler(y);
    Runge(y);
    addams(y);
        return 0;
}


