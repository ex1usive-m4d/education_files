//
//  main.cpp
//  method_simple_interation
//
//  Created by Иван on 03.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
/*
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main()
{
    // Считываем размер вводимой матрицы
    int size;
    cin >> size;
    
    // Будем хранить матрицу в векторе, состоящем из
    // векторов вещественных чисел
    vector <vector <long double> > matrix;
    
    // Матрица будет иметь размер (size) x (size + 1),
    // c учетом столбца свободных членов
    matrix.resize (size);
    for (int i = 0; i < size; i++)
    {
        matrix[i].resize (size + 1);
        
        for (int j = 0; j < size + 1; j++)
        {
            cin >> matrix[i][j];
        }
    }
    
    // Считываем необходимую точность решения
    long double eps;
    cin >> eps;
    
    // Введем вектор значений неизвестных на предыдущей итерации,
    // размер которого равен числу строк в матрице, т.е. size,
    // причем согласно методу изначально заполняем его нулями
    vector <long double> previousVariableValues (size, 0.0);
    
    // Будем выполнять итерационный процесс до тех пор,
    // пока не будет достигнута необходимая точность
    while (true)
    {
        // Введем вектор значений неизвестных на текущем шаге
        vector <long double> currentVariableValues (size);
        
        // Посчитаем значения неизвестных на текущей итерации
        // в соответствии с теоретическими формулами
        for (int i = 0; i < size; i++)
        {
            // Инициализируем i-ую неизвестную значением
            // свободного члена i-ой строки матрицы
            currentVariableValues[i] = matrix[i][size];
            
            // Вычитаем сумму по всем отличным от i-ой неизвестным
            for (int j = 0; j < size; j++)
            {
                if (i != j)
                {
                    currentVariableValues[i] -= matrix[i][j] * previousVariableValues[j];
                }
            }
            
            // Делим на коэффициент при i-ой неизвестной
            currentVariableValues[i] /= matrix[i][i];
        }
        
        // Посчитаем текущую погрешность относительно предыдущей итерации
        long double error = 0.0;
        
        for (int i = 0; i < size; i++)
        {
            error += abs (currentVariableValues[i] - previousVariableValues[i]);
        }
        
        // Если необходимая точность достигнута, то завершаем процесс
        if (error < eps)
        {
            break;
        }
        
        // Переходим к следующей итерации, так
        // что текущие значения неизвестных
        // становятся значениями на предыдущей итерации
        previousVariableValues = currentVariableValues;
    }
    
    // Выводим найденные значения неизвестных с 8 знаками точности
    for (int i = 0; i < size; i++)
    {
        printf ("%.8llf ", previousVariableValues[i]);
    }
    
    return 0;
}*/

#include <iostream>
#include<iostream>
#include<math.h>

using namespace std;
int main()
{
    int i, j;
     long double a[3][3] = { { 0, -0.6492537, -0.033851 },
                        { 0.5131148, 0, -0.2655738 },
                        { 0.2015504, -0.3626184, 0 } };
   long double s[3] = {0.0, 0.0, 0.0};
     long double y[3] = { 2.3000, -4.8000, 1.000 };
     long double z[3] = { -0.800995, -5.7352459, -1.2411714 };
    
    long double Xold[3], Xnew[3], eps, sum;
    
    for (i = 0; i<3; i++)
    {
        Xold[i] = y[i];
        
    }
  
    eps = 0.0001;
    int d = 0;
    long double max = 0;
    do
    {
        d++;

        max = 0;
        for (i = 0; i <= 2; i++)
        {
            sum = 0;
            for (j = 0; j <= 2; j++)
            {
                sum += (a[i][j] * Xold[j]);
                 s[i] = sum;
            }
            
            Xnew[i] = s[i] + z[i];
           
            cout << "x[" << i + 1 << "]=" << Xnew[i] << "   ";
            if (max<fabs(Xnew[i] - Xold[i]))
                max = fabs(Xnew[i] - Xold[i]);
            
        }
        cout << endl;
        for (i = 0; i <= 2; i++)
            Xold[i] = Xnew[i];
    } while (max>eps);
    
    cout << endl;
    cout << "Kol-vo iterasii=";
    cout << d << endl;
    cout << endl;
    
    cout << "Reshenie:" << endl;
    for (i = 0; i<3; i++)
        cout << "x[" << i + 1 << "]=" << Xnew[i] << endl;
    
   // _getch();
    return 0;
}

/*
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main()
{
    // Считываем размер вводимой матрицы
    int size;
    cin >> size;
    
    // Будем хранить матрицу в векторе, состоящем из
    // векторов вещественных чисел
    vector <vector <long long double> > matrix;
    
    // Матрица будет иметь размер (size) x (size + 1),
    // c учетом столбца свободных членов
    matrix.resize (size);
    for (int i = 0; i < size; i++)
    {
        matrix[i].resize (size + 1);
        
        for (int j = 0; j < size + 1; j++)
        {
            cin >> matrix[i][j];
        }
    }
    
    // Считываем необходимую точность решения
    long long double eps;
    cin >> eps;
    
    // Введем вектор значений неизвестных на предыдущей итерации,
    // размер которого равен числу строк в матрице, т.е. size,
    // причем согласно методу изначально заполняем его нулями
    vector <long long double> previousVariableValues (size, 0.0);
    
    // Будем выполнять итерационный процесс до тех пор,
    // пока не будет достигнута необходимая точность
    while (true)
    {
        // Введем вектор значений неизвестных на текущем шаге
        vector <long long double> currentVariableValues (size);
        
        // Посчитаем значения неизвестных на текущей итерации
        // в соответствии с теоретическими формулами
        for (int i = 0; i < size; i++)
        {
            // Инициализируем i-ую неизвестную значением
            // свободного члена i-ой строки матрицы
            currentVariableValues[i] = matrix[i][size];
            
            // Вычитаем сумму по всем отличным от i-ой неизвестным
            for (int j = 0; j < size; j++)
            {
                if (i != j)
                {
                    currentVariableValues[i] -= matrix[i][j] * previousVariableValues[j];
                }
            }
            
            // Делим на коэффициент при i-ой неизвестной
            currentVariableValues[i] /= matrix[i][i];
        }
        
        // Посчитаем текущую погрешность относительно предыдущей итерации
        long long double error = 0.0;
        
        for (int i = 0; i < size; i++)
        {
            error +=fabs (currentVariableValues[i] - previousVariableValues[i]);
        }
        
        // Если необходимая точность достигнута, то завершаем процесс
        if (error < eps)
        {
            break;
        }
        
        // Переходим к следующей итерации, так
        // что текущие значения неизвестных
        // становятся значениями на предыдущей итерации
        previousVariableValues = currentVariableValues;
    }
    
    // Выводим найденные значения неизвестных с 8 знаками точности
    for (int i = 0; i < size; i++)
    {
        printf ("%.8llf ", previousVariableValues[i]);
    }
    
    return 0;   
}
*/
/*
#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h>
using namespace std;

int main()
{   ifstream in ("matrix.txt");
    int i,j,k=0, p=0;
    long double a[3][4], x[3]={2.3000, -4.8000, 1.000}, b[3], aa[3][3], g, aaa[3][2], c[3]={2.3, -4.8, 1};
    for(i=0; i<3; i++)
    {
        for(j=0; j<4; j++)
        {
            in >> a[i][j];
        }
        b[i]=a[i][3];
    }
    for(i=0; i<3; i++)
        for(j=0; j<4; j++)
        {
            if(j==3) cout<<a[i][j]<<endl;
            else cout<<a[i][j]<<" ";
        }
    cout<<endl;
    for(i=0; i<3; i++)
    {
        g=a[i][i]; //cout<<"g="<<g<<endl;
        for(j=0; j<3; j++)
        {
            aa[i][j]=a[i][j]/g;
            b[i]=b[i]/g;
            
        }
    }
    for(i=0; i<3; i++)
    {
        k=0;
        for(j=0; j<3; j++)
        {
            if (aa[i][j]!=1) { aaa[i][k]=aa[i][j]; k++;}//aa[i][j]=aaa[i][k]; k++; }
            else ;
        }
    }
    cout<<endl;
    for(i=0; i<3; i++)
        cout<<b[i]<<" "; cout<<endl<<endl; g=0; k=0;
    
    for(i=0; i<3; i++)
        for(j=0; j<2; j++)
        {
            if(j==1) cout<<aaa[i][j]<<endl;
            else cout<<aaa[i][j]<<" ";
        }
   c[0]=x[0];
    do
    {
        
        for (i=0; i<2; i++)
        {
        }
        
        if (abs(x[i]-c[i])<0.0001) break;
        
    }
    while (abs(x[0]-c[0]) > 0.0001);
    
    
    /*
       for(i=0; i<3; i++)
     for(j=0; j<2; j++)
     {
     if(j==1) cout<<aaa[i][j]<<endl;
     else cout<<aaa[i][j]<<" ";
     }
          for(i=0; i<3; i++)
     for(j=0; j<3; j++)
     {
     if(j==2) cout<<aa[i][j]<<endl;
     else cout<<aa[i][j]<<" ";
     }
     cout<<endl;cout<<endl;
     for(i=0; i<3; i++)
     cout<<b[i]<<" ";
    */
    
    
//    return 0;}
