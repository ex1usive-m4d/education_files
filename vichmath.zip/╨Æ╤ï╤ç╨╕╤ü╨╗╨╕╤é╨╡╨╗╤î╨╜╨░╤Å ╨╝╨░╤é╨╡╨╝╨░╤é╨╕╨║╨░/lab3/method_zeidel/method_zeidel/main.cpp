//
//  main.cpp
//  method_zeidel
//
//  Created by Иван on 25.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <cmath>

using namespace std;
const int n=3;
// Условие окончания
bool converge(double *xk, double *xkp)
{ double eps=0.0001;
    double norm = 0;
    for (int i = 0; i < n; i++)
    {
        norm += xk[i] - xkp[i];
    }
    if(abs(norm) > eps)
        return false;
    return true;
}

/*
 Ход метода, где:
 a[n][n] - Матрица коэффициентов
 x[n], p[n] - Текущее и предыдущее решения
 b[n] - Столбец правых частей
 Все перечисленные массивы вещественные и
 должны быть определены в основной программе,
 также в массив x[n] следует поместить начальное
 приближение столбца решений (например, все нули)
 */
int main(){
    int k=0;
    double a[n][n] = { {1, -0.6492537, -0.033581 },
        { 0.5131148, 1, -0.2655738 },
        { 0.2015504,  -0.3626184 ,1} };
    double x[n] = {2.3, -4.8, 1},p[n],b[n]={-0.800995,-5.7352459,-1.2411714};

    do
    {
        for (int i = 0; i < n; i++)
            p[i] = x[i];
        
        for (int i = 0; i < n; i++)
        {
            double var = 0;
            for (int j = 0; j < i; j++)
                var += (a[i][j] * x[j]);
            for (int j = i+1; j < n; j++)
                var += (a[i][j] * p[j]);
            x[i] = var+b[i] ;
        }k++;

    }
    while (!converge(x, p));
    cout<<"количество итераций:"<<k<<endl;
    for(int i=0;i<n;i++)cout<<x[i]<<" ";
    return 0;
}

/*
#include <iostream>
#include <math.h>
#include <ccomplex>
using namespace std;
const int n=3;
int main()
{
    
    double a[n][n] = { { -0.6492537, -0.033581, -0.800995 },
        { 0.5131148,  -0.2655738, -5.7352459 },
        { 0.2015504,  -0.3626184, -1.2411714 } };
    double b[3];
    double x[3] = {2.3, -4.8, 1};
    int k=0, m, i, j;
    cout << "Матрица: " << endl;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
            cout << a[i][j] << " ";
        cout << endl;
    }
    cout << " начальные приближ ";
    for (i = 0; i < n; i++) cout << x[i] << " ";
    cout << endl;
    
    do
    {

        //cout << "Решение: " << endl;
       // cout << k << " : "<<x[0]<<" "<<x[1]<<" "<<x[2]<<endl;
       
        for(i=0;i<n;i++)
        x[0] = a[0][0] * x[1] + a[0][1] * x[2] + a[0][2];
        x[1] = a[1][0] * x[0] + a[1][1] * x[2] + a[1][2];
        x[2] = a[2][0] * x[0] + a[2][1] * x[1] + a[2][2];
        b[0] = a[0][0] * x[1] + a[0][1] * x[2] + a[0][2];
        b[1] = a[1][0] * x[0] + a[1][1] * x[2] + a[1][2];
        b[2] = a[2][0] * x[0] + a[2][1] * x[1] + a[2][2];
        
        k++;
       // if (b[0]-x[0]<0.0001) {break;}
    } while(abs(b[0]-x[0])>0.00001);
  
    return 0;
}*/
