//
//  main.cpp
//  lab9
//
//  Created by Иван on 23.11.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
/*
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream in ("data.txt");
double f(double x)
{
    return exp(cos(x));
}
int main()
{int i, n, l;
    double a=1,b=0,h, x, sum=0, sum1=0, sum2=0;
    cout<<"Enter n:\n";
    cin>>n;
    h=(a-b)/n;
    
        cout<<"\nLeft rectangle:\n";
        for(i=0; i<n-1; i++)
        {
            x=a+i*h;
            sum=sum+f(x);
        }
        sum=h*sum; cout<<"sum="<<sum<<endl;
    sum=0;
        cout<<"\nRight rectangle:\n";
        for(i=1; i<n; i++)
        {
            x=a+i*h;
            sum=sum+f(x);
        }
    sum=h*sum; cout<<"sum="<<sum<<endl;sum=0;
        cout<<"\nMiddle rectangle:\n";
        for(i=1; i<n; i++)
        {
            x=a+i*h;
            sum=sum+f(x+h/a);
        }
    sum=h*sum; cout<<"sum="<<sum<<endl;sum=0;
    
    
            
            cout<<"\nTrapezoid\n";
            for(i=1; i<n-1; i++)
            {
                x=a+i*h;
                sum=sum+f(x);
            }
            sum=(sum+1/2*f(a)+1/2*f(b))*h;
    cout<<"sum="<<sum<<endl;sum=0;

            cout<<"\nSimpson:\n";
            for(i=0; i<(2*n-1); i=i+2)
            {
                x=a+i*h;
                sum1=sum1+f(x);
            }
            for(i=1; i<(2*n-2); i=i+2)
            {
                x=a+i*h;
                sum2=sum2+f(x);
            }

            sum=h/3*(f(a)+f(b)+4*sum1+2*sum2);
            cout<<"sum="<<sum<<endl;


        return 0;
}*/
#include <iostream>
#include <cmath>
#include <math.h>
using namespace std;
double f(double x)
{
    return x*x;
}
void left_rect(double a,double h,double x,int n){ //////Формула левых прямоугольников
    double integ=0;
for (int i = 0; i < n; i++)
{
    x = a + i*h;
    integ = integ + f(x);
    
}
integ = integ*h;
cout << "Left Rectangle:" << integ << endl ;
}

void right_rect(double a,double h,double x,int n){
    double integ=0;
    for (int i = 1; i < n+1; i++)
{
    x = a + i*h;
    integ = integ + f(x);
}
    integ = integ*h;
    cout << "Right Rectangle:" << integ << endl;}

void sred_rect(double a,double h,double x,int n){
    double integ=0;
    
    for (int i = 0; i < n; i++)
    {
        x = a + i*h;
        integ = integ + f(x+(h/2));
    }
    integ = integ*h;
    cout << "Averange Rectangle:" << integ << endl << endl;}

void trap(double a,double b,double h,double x,int n){
    double integ=0;
    
    for (int i = 1; i < n; i++)
    {
        x = a + i*h;
        integ = integ + f(x);
    }
    integ = (integ + f(a) / 2 + f(b) / 2)*h;
    cout << "Trapizoid: " << integ << endl << endl;}

void simpson(double a,double b,double h,double x,int n){
   
    
    if (n%2>0) cout << "Решение по формуле Симпсона невозможно, т.к. n - нечетное число";
    else
    { double integ=0,sum=0;
        for (int i = 1; i < n; i=(i+2))
        {
            x = a + i*h;
            sum = sum + f(x);
        }
        integ += 4 * sum;
        sum = 0;
        
        for (int i = 2; i < n-1; i = (i + 2))
        {
            x = a + i*h;
            sum = sum + f(x);
        }
        integ += 2 * sum;
        
        integ = (integ + f(a) + f(b) / 2)*h/3;
        cout << "Simpson: " << integ;}
}
int main()
{
    long double x, y, h, sum=0,integ = 0,i = 0, a = 0, b = 3, n;
    int m;
    cout<<"how much sections:";
    cin >> n;
    h = (b - a) / n;

    left_rect(a,h,x,n);
    right_rect(a, h, x, n);
    sred_rect(a, h, x,n);
    trap( a, b, h, x, n);
    simpson(a, b, h, x, n);
    return 0;
}