//
//  main.cpp
//  interpolation_Langrange
//
//  Created by Иван on 19.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include <stdio.h>
#include <iostream>
using namespace std;
double InterpolateLagrangePolynomial (double x, double* x_values, double* y_values, int size)
{
    double lagrange_pol = 0;
    double basics_pol;
    
    for (int i = 0; i < size; i++)
    {
        basics_pol = 1;
        for (int j = 0; j < size; j++)
        {
            if (j == i) continue;//если условие выполняется то начинаем цикл заново, иначе
            basics_pol *= (x - x_values[j])/(x_values[i] - x_values[j]);//полином
        }
        lagrange_pol += basics_pol*y_values[i];//сумма Ln(x)
    }
    return lagrange_pol;
}

double testF(double x)
{
    return  x*x; // for example
}

int main()
{
    const int size = 5;
    double x_values[size];
    double y_values[size];
    double number;
    
    for (int i = 0; i < size; i++)
    {x_values[i]=i;
     cout<<"x["<<i+1<<"]:"<<x_values[i]<<" ";
        y_values[i] = testF(x_values[i]);
        cout<<"y[x]:"<<y_values[i]<<endl;
    }
    
    
    
    cin>>number;
    cout<<InterpolateLagrangePolynomial(number, x_values, y_values, size);
    
    return 0;
}