//
//  main.cpp
//  inter_Newton
//
//  Created by Иван on 07.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <stdio.h>
#include <cmath>
#include <stdlib.h>
using namespace std;
const  int n = 12;
/*{
double newton(double X,int n,double Xi[],double Yi[]){ //X=abs(X);
    double f, LN, XXX, XX=1.;
    int  i, j, k;
    for (i=1, LN=Yi[0]; i<n; i++)
    {
        XX *= (X-Xi[i-1]);
        for (j=0,f=0; j<=i; j++)
        {
            for (k=0,XXX=1.; k<=i; k++)
            {
                if (k!=j)
                    XXX *= Xi[j]-Xi[k];
                 //cout<<"factorial:"<<XXX<<endl;
            }
            // cout<<"factorial:"<<Xi[j]<<" "<<Xi[k]<<" "<<XXX<<endl;
            f += Yi[j]/XXX;
        }
        LN += XX * f;
    }
    return LN;
}
double inewton(double X,int n,double Xi[],double Yi[]){  double f, LN, XXX, XX=1.;
    int  i, j, k;
    for (i=n, LN=Yi[n-1]; i>0; i--)
    {
        XX *= (X-Xi[i-1]);
        for (j=i,f=Xi[n]; j>=0; j--)
        {
            for (k=i,XXX=1.; k>=0; k--)
            {
                if (k!=j)
                    XXX *= Xi[j]-Xi[k];
                //cout<<"factorial:"<<XXX<<endl;
            }
            // cout<<"factorial:"<<Xi[j]<<" "<<Xi[k]<<" "<<XXX<<endl;
            f += Yi[j]/XXX;
        }
        LN += XX * f;
    }
    return LN;
}
};*/

double Newton(double t, int n, double x[], double y[])
{
    double res = y[0], F, den;
    int i, j, k;
    for (i = 1; i < n; i++)
    {
        F = 0;
        for (j = 0; j <= i; j++)
        {
            den = 1;
            for (k = 0; k <= i; k++)
            {
                if (k != j) den *= (x[j] - x[k]);
            }
            F += y[j] / den;
        }
        for (k = 0; k < i; k++) F *= (t - x[k]);
        res += F;
    }
    return res;
}
double iNewton(double t, int n, double x[], double y[])
{ //t=abs(t);
    double res = y[0], F, den;
    int i, j, k;
    
    for (i = n; i > 0; i--)
    {
        F = 0;
        for (j = i; j >=0; j--)
        {
            den = 1;
            for (k = i; k >=0 ; k--)
            {
                if (k != j) den *= (x[j] - x[k]);
            }
            F += y[j] / den;
        }
        for (k = 0; k < i; k++) F *= (t - x[k]);
        res += F;
    }
    return res;
}
double testF(double x)
{
    return  x*x; // for example
}
int main ()
{   double z,s;
    double number;
    double Xi[n],Yi[n];
    for(int i=0;i<=n;i++)
    {
    Xi[i]=i-5;
      cout<<Xi[i]<<" ";
    Yi[i]=testF(Xi[i]);
    }
    cout<<endl;
    cin>>number;
    s=abs(Xi[1]-number);
    z=abs(Xi[n-1]-number);
    
      if(z<s)
            {cout<<"2 формула "<<iNewton(number,n,Xi,Yi)<<endl;}
      if(s<z)
            {cout<<"1 формула "<<Newton(number,n,Xi,Yi)<<endl;}
    
    return 0;
}

