//
//  main.cpp
//  lab6_newton
//
//  Created by Иван on 07.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

//
//  main.cpp
//  inter_Newton
//
//  Created by Иван on 07.12.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//
#include <iostream>
#include <stdio.h>
#include <cmath>
#include <stdlib.h>
using namespace std;
const  int n = 6;

class interpol
{public:
double Xi[n],Yi[n];
    interpol(){
        for(int i=0;i<=n;i++)
        { Xi[i]=i;
          Yi[i]=testF(Xi[i]);//cout<<Yi[i]<<endl;
        }};
    double Newton(double t, int n, double x[], double y[])
    {
        double res = y[0], F, den;
        int i, j, k;
        for (i = 1; i < n; i++)
        {
            F = 0;
            for (j = 0; j <= i; j++)
            {
                den = 1;
                for (k = 0; k <= i; k++)
                {
                    if (k != j) den *= (x[j] - x[k]);
                }
                F += y[j] / den;
            }
            for (k = 0; k < i; k++) F *= (t - x[k]);
            res += F;
        }
        return res;
    };
    double iNewton(double t, int n, double x[], double y[])
    { //t=abs(t);
        double res = y[0], F, den;
        int i, j, k;
        
        for (i = n; i > 0; i--)
        {
            F = 0;
            for (j = i; j >=0; j--)
            {
                den = 1;
                for (k = i; k >=0 ; k--)
                {
                    if (k != j) den *= (x[j] - x[k]);
                }
                F += y[j] / den;
            }
            for (k = 0; k < i; k++) F *= (t - x[k]);
            res += F;
        }
        return res;
    };
    void view(double num){
        if(abs(num-Xi[0])<abs(Xi[n]-num))
        cout<<"0";//cout<<"1 формула "<<Newton(num,n,Xi,Yi)<<endl;
        else //if(abs(Xi[n]-num)<abs(num-Xi[0]))
           cout<<"1"; //cout<<"2 формула "<<iNewton(num,n,Xi,Yi)<<endl;
    };
    double testF(double x)
    {
        return  x*x; // for example
    };


};

int main ()
{
    double number;
    
    interpol ob;
    cin>>number;
    interpol();
    ob.view(number);
    
    
    return 0;
}

