//
//  main.cpp
//  new Newton
//
//  Created by Иван on 01.11.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//модифицированный ньютон

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

double f(double x)
{
    return sin(2*x)-log(x);
}
double df(double x)
{
    return 2*cos(2*x)-1/x;
}
int main(int argc, char *argv[])
{ double eps=0.0001;
    double a,b,c=1.3,x,del,y;
    // cout <<" Введите a ";cin>>a;
    // cout <<"Введите b ";cin>>b;
    //cout <<"vvedite eps ";cin>>eps;
    int k=0;
    
    while (abs(f(c))>eps)
    {
        if (df(c)!=0)
        {
            c=c-f(c)/df(1.3);
        }
        
        cout<<k<<"|c= "<<c<<" f(x):"<<f(c)<<endl;
        k++;
        
    }
    cout<<"\nОтвет:"<<c<<endl;
    
    return 0;
}