//
//  main.cpp
//  division_of_section
//
//  Created by Иван on 31.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//метод деление отрезков пополам

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

double f(double x)
{
    return x*x-4;
}

int main(int argc, char *argv[])
{ double eps=0.0001;
    double a,b,c=0,x,del,y;
    cout <<" Введите a ";cin>>a;
    cout <<"Введите b ";cin>>b;
    //cout <<"vvedite eps ";cin>>eps;
    int k=0;
    while (abs(f(c))>eps)
    {        c=(a+b)/2;
        if (f(a)*f(c)<0)
        {
            b=c;
        }
        else 
        {
            a=c;
        }
        cout<<k<<"|c= "<<c<<" f(x):"<<f(c)<<endl;
        k++;

    }
   cout<<"\nОтвет:"<<c<<endl;
   
    return 0;
}
