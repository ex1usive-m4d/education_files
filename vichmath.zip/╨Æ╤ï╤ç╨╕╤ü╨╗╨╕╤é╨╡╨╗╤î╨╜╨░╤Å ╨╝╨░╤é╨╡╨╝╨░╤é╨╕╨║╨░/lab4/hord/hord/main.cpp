//
//  main.cpp
//  hord
//
//  Created by Иван on 01.11.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//метод хорд


#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

double f(double x)
{
    return x*x-4;
}

int main(int argc, char *argv[])
{ double eps=0.0001;
    double a,b,c=0,x,del,y;
    cout <<" Введите a ";cin>>a;
    cout <<"Введите b ";cin>>b;
    //cout <<"vvedite eps ";cin>>eps;
    int k=0;
    
   do {
       
            a=b-(b-a)*f(b)/(f(b)-f(a));
            b=a-(b-a)*f(a)/(f(a)-f(b));
            
        
        cout<<k<<"|x= "<<b<<" f(x):"<<f(b)<<endl;
        k++;
        
   }while (abs(b-a)>=eps);
    cout<<"\nОтвет:"<<b<<endl;
    
    return 0;
}
