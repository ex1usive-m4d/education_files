//
//  main.cpp
//  simple_interation
//
//  Created by Иван on 01.11.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

double f(double x)
{
    return sin(2*x)-log(x);
}

int main(int argc, char *argv[])
{   double eps=0.0001;
    double a=1.3,b,c=1.31,x,del,y;
    // cout <<" Введите a ";cin>>a;
    // cout <<"Введите b ";cin>>b;
    //cout <<"vvedite eps ";cin>>eps;
    int k=0;
    
    while (abs(f(c))>eps)
    {
        // if (df(c)!=0)
        b=c-a;
        c=c-b*f(c)/(f(c)-f(a));
        a+=b;
        
        cout<<k<<"|c= "<<c<<endl;
        k++;
        
    }
    cout<<"\nОтвет:"<<c<<endl;
    
    return 0;
}