//
//  main.cpp
//  simple_itheration
//
//  Created by Иван on 26.10.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include <iostream>
#include <cmath>

using namespace std;
double f1 (double x)
{
    return -1.5+sin(x-0.5);
}
double f2 (double y)
{
    return 0.5*(0.6+cos(y));
}
int main()
{int i;
   long double x0=0.13, y0=-1.8, x, y;
    for(i=0; i<50; i++)
    {
        cout<<"\n#"<<i<<endl;
        y=f1(x0); x=f2(y0);
        if ((abs(x-x0)<0.001)&&(abs(y-y0)<0.001))
        {i=50; cout<<"x="<<x<<endl<<"y="<<y<<endl<<"x-x0="<<abs(x-x0)<<"\ny-y0="<<abs(y-y0)<<endl; }
        else
        { cout<<"x="<<x<<endl<<"y="<<y<<endl<<"x-x0="<<abs(x-x0)<<"\ny-y0="<<abs(y-y0)<<endl; x0=x; y0=y; }
    }
    return 0;
}
