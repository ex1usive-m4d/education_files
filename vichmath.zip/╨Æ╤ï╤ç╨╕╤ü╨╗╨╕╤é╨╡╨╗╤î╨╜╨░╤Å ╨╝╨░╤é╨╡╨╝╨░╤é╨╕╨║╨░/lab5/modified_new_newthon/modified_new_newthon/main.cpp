//
//  main.cpp
//  modified_new_newthon
//
//  Created by Иван on 09.11.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int i=0;
    double A[2][2], B[2];
    double eps,x0 = 0.13, y0 = -1.8, x = 0.13, y = -1.8,del, del1,del2, delX, delY;
    
    A[0][0] = cos(x - 0.5);
    A[0][1] = -1;
    A[1][0] = 2;
    A[1][1] = sin(y);
    
    do
    {
        
        B[0] = -sin(x0 - 0.5) + y0 + 1.5;
        B[1] = -2 * x0 + cos(y0) + 0.6;
        cout << i << "  x0= " << x0 << "  y0= " << y0 ;
        
        
        del = A[0][0] * A[1][1] - A[0][1] * A[1][0];
        cout << "  del= " << del;
        
        del1 = B[0] * A[1][1] - B[1]*A[0][1];
        del2 = A[0][0] * B[1] - A[1][0] * B[0];
        
        delX = del1 / del;
        cout << "  delX= " << delX;
        
        delY = del2 / del;
        cout << "  delY= " << delY<<endl;
        
        x0 += delX;
        y0 +=delY;
        if (abs(delX) > abs(delY)) eps = abs(delX); else eps = abs(delY);
        i++;
        
    } while (eps>0.0001);
    cout << i << "  x0= " << x0 << "  y0= " << y0;
    cout << "  delX= " << delX;
    cout << "  delY= " << delY;
    
    return 0;
}

/*
 while (acc > e)
 {
 n++;
 xn = xm - funct(xm)/diff(xm);
 acc = fabs(xn - xm);
 cout << setw(2) << n << " " << xm << " " << xn << " " << acc << endl;
 xm = xn;
 }
 */
