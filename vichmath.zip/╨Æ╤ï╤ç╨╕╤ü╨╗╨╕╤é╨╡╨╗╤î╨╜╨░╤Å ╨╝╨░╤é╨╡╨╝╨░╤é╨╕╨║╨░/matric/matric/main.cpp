//
//  main.cpp
//  matric
//
//  Created by Иван on 14.09.15.
//  Copyright (c) 2015 ____IVAN_BOLSHAKOV_____. All rights reserved.
// матрицу умножаешь на число,умножение матриц,сложение 2 матриц

#include <iostream>
#include <cmath>
using namespace std;
int main(int argc, const char * argv[]) {
    int i,n,m,k=0,num,m1,g=0,t=0;
    int a[100][100],b[100][100],c[100][100],s;
    cout<<"Введите кол-во строк";
    cin>>n;
    cout<<"Введите кол-во столбцов";
    cin>>m;
    
    for (i=0;i<n;i++)
        for(int j=0;j<m;j++)
        {cin>>a[i][j];
    }
    
    cin>>num;
    while(num!=0)
    {
        
    switch (num)
    {
        case 0:
        {
            break;
        }
        case 1:
        { cout<<"введите число ";
            cin>>m1;
            for (i=0;i<n;i++)
            {cout<<"\n";
                for(int j=0;j<m;j++)
                {
                   
                    cout<<m1*a[i][j]<<" ";
                }
            }
            
            break;
    }
        
        case 2:{
            cout<<"введите 2 матрицу размерности ["<<n<<"]"<<"["<<m<<"]\n";
            for (i=0;i<n;i++)
                for(int j=0;j<m;j++)
                {cin>>b[i][j];
                }
            
        cout<<"сложение матриц\n";
            for (i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {   s=a[i][j]+b[i][j];
                    cout<<s<<" ";}cout<<"\n";}
            
            break;}
        case 3:
        {   cout<<"введите количество строк:";
            cin>>g;
            cout<<"введите количество столбцов:";
            cin >>t;
            cout<<"введите матрицу:\n";
            for(i=0;i<g;i++)
                for(int j=0;i<t;j++)
                    cin>>b[i][j];
           // if (n!=t) {cout<<"количество строк в матрицу А = количеству стоблцов в Б";exit(100);}
            cout<<"умножение матриц";
            
            for (i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    c[i][j] = 0;
                    for (k = 0; k < t; k++)
                        c[i][j] += a[i][k] * b[k][j];
                }
            }
          
            for (i = 0; i < t; i++)
            {
                for (int j = 0; j < n; j++)
                    cout << " " << c[i][j];
                cout << endl;
            }
            break;
        }
            
    }
   cout<<"\n"<<"выберите что с делать с матрицей";
        cin>>num;}
    cout<<endl;
    return 0;
}
